import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:20:06 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class OptimizingStrategy extends Strategy {

	int numTurns = 1;

	public OptimizingStrategy(PlanetWars pw) {
		super(pw);
	}

	public OptimizingStrategy(PlanetWars pw, int numTurns) {
		super(pw);
		this.numTurns = numTurns;
	}


	protected abstract boolean FilterPlanet(OrderSearchNode sn, Planet p);
	protected abstract boolean TestState(OrderSearchNode osn);
	
	@Override
	public OrderSearchNode Run(OrderSearchNode startNode) {
		int nTried = 0;
		
		Queue<OrderSearchNode> searchQueue = new LinkedList<OrderSearchNode>();
		searchQueue.add(startNode);

		OrderSearchNode optimalOrders = startNode;
		
		long ticks = System.nanoTime();

		while (searchQueue.size() > 0)
		{
			OrderSearchNode currentNode = searchQueue.poll();
			nTried++;
//			Logger.AppendLog("POLLED NEW STATE, DONE " + nTried + " REMAIN: " + searchQueue.size(), false);

			boolean bAnyOrders = false;
			for (Planet p : pw.Planets())
			{
				PossibleOrder poLast = currentNode.orderList.size() > 0 ? currentNode.orderList.get(currentNode.orderList.size() - 1) : null;

				if (poLast != null && p.PlanetID() <= poLast.dst.PlanetID()) {
//					Logger.AppendLog("IGNORE " + p.PlanetID(), false);
					continue;
				}

				if (!FilterPlanet(currentNode, p)) {
//					Logger.AppendLog("IGNORE " + p.PlanetID(), false);
					continue;
				}

				for (int nt = 0; nt < numTurns; ++nt) {
					PossibleOrder po = (new PlanetAttacker(pw, p, currentNode, nt)).getResult();
					if (po != null)
					{
	//					Planet ps = po.parts.get(0).p;
	//					Logger.AppendLog("PLANET CAPTURE " + po.toString(), false);

						OrderSearchNode nn = new OrderSearchNode(pw, currentNode, po);

						searchQueue.add(nn);
	//					Logger.AppendLog("NEW SEARCH NODE: " + nn.prediction.get(pw.MyPlanets().get(0)).futureNumShips[0], false);
						bAnyOrders = true;
					}
				}
			}

			if (!bAnyOrders) {
		   		if (TestState(currentNode)) {
//				   Logger.AppendLog("NEW GROWTH MAX " + currentNode.getGrowthRate() + "\nREMAIN " + currentNode.prediction.get(pw.MyPlanets().get(0)).futureSafeAvailable[0] , false);
//					for (PossibleOrder po : currentNode.orderList) {
//						Logger.AppendLog(po.toString(), false);
//					}
					optimalOrders = currentNode;
				}
			}

//			Logger.AppendLog( "DONE NODE CREATION IN: " + ((System.nanoTime() - ticks) / 1000) + "us", false);
		}

//		Logger.AppendLog( "TRIED " + nTried + " NODES IN: " + ((System.nanoTime() - ticks) / 1000) + "us", false);

		return optimalOrders;
	}


}
