/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 30, 2010
 * Time: 5:17:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProtectPlanetStrategy extends OptimizingStrategy {
	Planet target;
	int targetTime, playerID;

	public ProtectPlanetStrategy(PlanetWars pw, int player, Planet test, int time) {
		super(pw, time);
		target = test;
		targetTime = time;
		playerID = player;
	}

	@Override
	protected boolean FilterPlanet(OrderSearchNode sn, Planet p) {
		return p == target;
	}

	@Override
	protected boolean TestState(OrderSearchNode osn) {
		int [] fo = osn.prediction.get(target).futureOwner;
		int tt = fo.length <= targetTime ? fo.length - 1 : targetTime;
		
		return fo[tt] == playerID;
	}

	@Override
	public String getName() {
		return "PROTECT " + target.PlanetID();
	}
}
