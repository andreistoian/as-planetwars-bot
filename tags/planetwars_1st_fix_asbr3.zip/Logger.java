import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:11:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class Logger {
	static boolean debug = true;

	static private Socket debugSoc;
	static private PrintWriter debugPW;
	
	public static void AppendLog(String data)
	{
		AppendLog(data, true);
	}

	public static void ResetLog(boolean dbg) {
		debug = dbg; 
		if (debug)
		{
			File f = new File("andrei.txt");
			f.delete();

			f = new File("debug.txt");
			f.delete();

			try {
				debugSoc = new Socket("localhost", 10001);
				debugPW = new PrintWriter(debugSoc.getOutputStream());
			} catch (Exception ignore) {
			}
		}
	}

	public static void CloseLog() {
		if (debug)
		{
			debugPW.close();
			try {
				debugSoc.close();
			} catch (Exception ignore) {
			}
		}		
	}

	public static void AppendLog(String data, boolean sock)
	{
		if (debug)
		{
			try {
				PrintWriter dbgpw;

				if (sock) {
					dbgpw = new PrintWriter(new FileWriter("andrei.txt", true));
					dbgpw.println(data);
					dbgpw.close();
				}

				dbgpw = new PrintWriter(new FileWriter("debug.txt", true));
				dbgpw.println(data);
				dbgpw.flush();
				dbgpw.close();

			} catch (IOException err) {
				System.out.println("ERROR");
			}

			if (sock)
			{
				try {
					if (debugPW != null)
					{
						debugPW.println(data);
						debugPW.flush();
					}
				} catch (Exception ignore) {
				}
			}
		}
	}

	public static void PrintException(Exception e) {
		if (debug) {
			try {
				PrintWriter dbgpw = new PrintWriter(new FileWriter("debug.txt", true));
				e.printStackTrace(dbgpw);
				dbgpw.close();
			} catch (IOException ignore) {
			}
		}
	}
}
