/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 30, 2010
 * Time: 5:17:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProtectPlanetStrategy {
}
