import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:06:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class AttackStrategy extends Strategy {
	int minGrowth = Integer.MAX_VALUE;
	Map<Integer, Integer> allClusters;

	public AttackStrategy(PlanetWars pw, Map<Integer, Integer> clusters) {
		super(pw);
		this.allClusters = clusters;
	}

	public List<Planet> GetReadyClusters(PlanetWars pw, OrderSearchNode osn, Map<Integer,Integer> clusterTargets) {
		List<Planet> res = new ArrayList<Planet>();
		for (int cl : clusterTargets.keySet()) {
			int pcl = osn.prediction.get(pw.Planets().get(cl)).futureAvailable[0];

			Planet ct = pw.Planets().get(clusterTargets.get(cl));
			int d = pw.Distance(cl, clusterTargets.get(cl));
			int pct = osn.prediction.get(ct).futureInputNeeded[d];

			if (pcl > Math.max(osn.prediction.get(ct).undefendableNum[d], pct))
			{
//				Logger.AppendLog("CLUSTER HEAD " + cl + "(" + pcl + ")" + " ATTACK " + ct.PlanetID() + " (" + d + ", " + pct + ")", false);
				res.add(pw.Planets().get(cl));
			}
		}

		return res;
	}

	public String getName() { return "ATTACK"; }

	@Override
	public OrderSearchNode Run(OrderSearchNode osn) {
		OrderSearchNode newnode = osn;

		List<Planet> readyClusters = GetReadyClusters(pw, osn, allClusters);
		
		for (Planet pcl : readyClusters) {
			int tid = allClusters.get(pcl.PlanetID());

			if (osn.prediction.get(pcl).futureAvailable[0] > 0) {
				PossibleOrder po = new PossibleOrder(pw.GetPlanet(tid), 0);
				po.parts.add(new PlanetOrder(pcl, osn.prediction.get(pcl).futureAvailable[0], 0, 1));

				newnode = new OrderSearchNode(pw, newnode, po);
			}
		}
		return newnode;
	}
}
