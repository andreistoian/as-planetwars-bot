/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 29, 2010
 * Time: 6:22:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class SnatchStrategy extends OptimizingStrategy {
	int maxGrowth = 0;
	int maxShips = 0;

	public SnatchStrategy(PlanetWars pw) {
		super(pw);
	}

	@Override
	protected boolean FilterPlanet(OrderSearchNode sn, Planet p) {
		float minDistMe = 10000, minDistHim = 10000;
		for (Planet q : pw.Planets()) {
			if (p == q) continue;
			
			int dist = pw.Distance(p.PlanetID(), q.PlanetID());
			if (q.Owner() == 1) {
				if (dist < minDistMe)
					minDistMe = dist;
			} else if (q.Owner() == 2) {
				if (dist < minDistHim)
					minDistHim = dist;
			}
		}
		return p.Owner() == 0 && sn.getFinalOwner(p) == 2 && minDistMe < minDistHim;
	}

	@Override
	protected boolean TestState(OrderSearchNode osn) {
		int gr = osn.getGrowthRate();
		int na = osn.getAvailShips();

		if (gr > maxGrowth)
		{
			maxGrowth = gr;
			maxShips = na;
			return true;
		}
		else if (gr == maxGrowth && na > maxShips)
		{
			maxShips = na;
			return true;
		}
		return false;
	}

	@Override
	public String getName() {
		return "SNATCH";
	}
}
