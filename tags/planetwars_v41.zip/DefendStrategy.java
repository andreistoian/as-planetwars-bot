/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:07:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefendStrategy extends OptimizingStrategy {
	int maxGrowth = 0;
	int playerID = 1;
	
	public DefendStrategy(PlanetWars pw) {
		super(pw);
	}
	public DefendStrategy(PlanetWars pw, int playerID) {
		super(pw);
		this.playerID = playerID;
	}

	public boolean FilterPlanet(OrderSearchNode sn, Planet p) {
		int enemyID = playerID == 1 ? 2 : 1;
		if (p.Owner() == playerID && sn.getFinalOwner(p) == enemyID)
			return true;
		return false;
	}

	public void ResetOptimal() {
		maxGrowth = 0;
	}

	public boolean TestState(OrderSearchNode osn) {
		int tg = osn.getGrowthRate();
		if (tg > maxGrowth)
		{
			maxGrowth = tg;
			return true;
		}
		return false;
	}

	public String getName() { return "DEFEND"; }
}