import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:04:02 PM
 * To change this template use File | Settings | File Templates.
 */
class OrderSearchNode {
	public HashMap<Planet, PlanetPrediction> prediction;
	public ArrayList<ArrayList<PlanetOrder>> partialOrders;
	public ArrayList<PossibleOrder> orderList;

	public OrderSearchNode(PlanetWars pw) {
		this.prediction = new HashMap<Planet, PlanetPrediction>();
		for (Planet p : pw.Planets())
			this.prediction.put(p, ComputeFutureState(p));

		partialOrders = new ArrayList<ArrayList<PlanetOrder>>(pw.NumPlanets());
		for (int i = 0; i < pw.NumPlanets(); ++i)
			partialOrders.add(null);

		orderList = new ArrayList<PossibleOrder>();
	}

	public OrderSearchNode(PlanetWars pw, OrderSearchNode n, PossibleOrder po) {
		this.prediction = new HashMap<Planet, PlanetPrediction>();
		partialOrders = new ArrayList<ArrayList<PlanetOrder>>(pw.NumPlanets());

		for (int i = 0; i < pw.NumPlanets(); ++i) {
			if (n.partialOrders.get(i) != null)
				this.partialOrders.add(new ArrayList<PlanetOrder>(n.partialOrders.get(i)));
			else
				this.partialOrders.add(null);
		}

		for (PlanetOrder pop : po.parts) {
			if (this.partialOrders.get(pop.p.PlanetID()) == null)
				this.partialOrders.set(pop.p.PlanetID(), new ArrayList<PlanetOrder>());

			this.partialOrders.get(pop.p.PlanetID()).add(new PlanetOrder(pop.p, -pop.nShips, pop.nTime));

//				AppendLog("ADDED PLANET ORDER FOR " + pop.p.PlanetID() + " - " + (-pop.nShips) + " at " + pop.nTime, false);

			if (this.partialOrders.get(po.dst.PlanetID()) == null)
				this.partialOrders.set(po.dst.PlanetID(), new ArrayList<PlanetOrder>());

			this.partialOrders.get(po.dst.PlanetID()).add(new PlanetOrder(po.dst, pop.nShips, pop.nTime + po.dst.getDistances()[pop.p.PlanetID()]));

//				AppendLog("ADDED PLANET ORDER FOR " + po.dst.PlanetID() + " - " + (pop.nShips) + " at " + pop.nTime + po.dst.getDistances()[pop.p.PlanetID()], false);
		}

		for (Planet p : pw.Planets()) {
			if (this.partialOrders.get(p.PlanetID()) != null)
			{
//					AppendLog("COMPUTING PREDICTION FOR " + p.PlanetID(), false);
//					AppendLog("DEBUG BEFORE:\n"+n.prediction.get(p).toString(p.PlanetID())+"\nENDDEBUG", false);
				this.prediction.put(p, ComputeFutureState(p, this.partialOrders.get(p.PlanetID())));
//					AppendLog("DEBUG AFTER:\n"+this.prediction.get(p).toString(p.PlanetID())+"\nENDDEBUG", false);
			}
			else
			{
//					AppendLog("COPYING PREDICTION FOR " + p.PlanetID(), false);
				this.prediction.put(p, n.prediction.get(p));
			}
		}

		orderList = new ArrayList<PossibleOrder>(n.orderList);
		orderList.add(po);
	}

	public int getGrowthRate() {
		int totalGrowth = 0;
		for (Planet p : this.prediction.keySet())
			if (getFinalOwner(p) == 1)
				totalGrowth += p.GrowthRate();

		return totalGrowth;
	}

	public int getAvailShips() {
		int total = 0;
		for (Planet p : this.prediction.keySet())
			if (p.Owner() == 1)
				total += prediction.get(p).futureAvailable[0];

		return total;
	}

	public int getFinalOwner(Planet p) {
		return this.prediction.get(p).futureOwner[MyBot.maxDistance - 1];
	}

	private PlanetPrediction ComputeFutureState(Planet p) {
		return ComputeFutureState(p, -1, -1);
	}

	private PlanetPrediction ComputeFutureState(Planet p, int addShips, int addTime) {
		List<PlanetOrder> lst = new ArrayList<PlanetOrder>();
		lst.add(new PlanetOrder(p, addShips, addTime));
		return ComputeFutureState(p, lst);
	}

	private PlanetPrediction ComputeFutureState(Planet p, List<PlanetOrder> add) {
		int[] futureNumShips = new int[MyBot.maxDistance];
		int[] futureOwner = new int[MyBot.maxDistance];
		int[] futureInputNeeded = new int[MyBot.maxDistance];
		int[] futureAvailable = new int[MyBot.maxDistance];

		futureOwner[0] = p.Owner();
		futureNumShips[0] = p.NumShips();

		for (PlanetOrder po : add) {
			if (po.nTime == 0)
				futureNumShips[0] += po.nShips;
		}

		futureAvailable[0] = futureOwner[0] == 1 ? futureNumShips[0] : 0;

		int minFleets = futureNumShips[0];

		HashMap<Integer, Integer> participants = new HashMap<Integer, Integer>();

		for (int i = 1; i < futureNumShips.length; ++i)
		{
			futureOwner[i] = futureOwner[i-1];
			futureNumShips[i] = futureNumShips[i-1];

			if (futureOwner[i] != 0)
				futureNumShips[i] += p.GrowthRate();

			List<Fleet> fleetsNow = new ArrayList<Fleet>();
			for (Fleet f : p.getFleets())
				if (f.TurnsRemaining() == i)
					fleetsNow.add(f);

			participants.clear();
			participants.put(futureOwner[i], futureNumShips[i]);

			int numForcePlayer1 = 0, numForcePlayer2 = 0;

			for (Fleet f : fleetsNow) {
				if (f.Owner() == 1)
					numForcePlayer1 += f.NumShips();
				else
					numForcePlayer2 += f.NumShips();
			}

			for (PlanetOrder po : add) {
				if (po.nTime == i)
					numForcePlayer1 += po.nShips;
			}

			if (participants.containsKey(1)) {
				participants.put(1, participants.get(1) + numForcePlayer1);
			} else {
				participants.put(1, numForcePlayer1);
			}

			if (participants.containsKey(2)) {
				participants.put(2, participants.get(2) + numForcePlayer2);
			} else {
				participants.put(2, numForcePlayer2);
			}

			int maxShips = 0, maxOwner = -1, secShips = 0;
			for (int own : participants.keySet()) {
				int sh = participants.get(own);
				if (sh > secShips) {
					if (sh > maxShips) {
						secShips = maxShips;
						maxShips = sh;
						maxOwner = own;
					} else
						secShips = sh;
				}
			}

			int result = maxShips - secShips;

			int startOwner = futureOwner[i];

			futureNumShips[i] = result;

			if (result > 0)
				futureOwner[i] = maxOwner;

			if (futureOwner[i] == 1)
			{
				for (int j = 1; j <= i; ++j)
					futureInputNeeded[j] = 0;
			}
			else
			{
				futureInputNeeded[i] = futureNumShips[i] + 1;
				int arrived = startOwner == 2 ? numForcePlayer1 : numForcePlayer2;
				if (arrived > 0)
				{
					for (int j = 0; j <= i-1; ++j)
					{
						if (startOwner == 1)
							futureInputNeeded[j] = futureNumShips[i];
						else
							futureInputNeeded[j] += numForcePlayer1;
					}
				}
			}

			if (futureOwner[i] == 2) {
				for (int j = 0; j <= i; ++j)
					futureAvailable[j] = 0;
			}
			else if (futureOwner[i] == 1) {
				if (futureNumShips[i] < minFleets)
				{
					minFleets = futureNumShips[i];
					for (int j = i; j >= 0 && futureOwner[j] == 1; --j) {
						futureAvailable[j] = minFleets;
					}
				}
				else
					futureAvailable[i] = futureNumShips[i] - 1;
			}
		}


		PlanetPrediction newpp = new PlanetPrediction(futureNumShips, futureOwner, futureInputNeeded, futureAvailable);
//		Logger.AppendLog(newpp.toString(p.PlanetID()));
//			Logger.AppendLog(availFleets + "");
		return newpp;
	}	
}