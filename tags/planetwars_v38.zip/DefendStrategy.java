/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:07:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefendStrategy extends OptimizingStrategy {
	int maxGrowth = 0;
	public DefendStrategy(PlanetWars pw) {
		super(pw);
	}
	public boolean FilterPlanet(OrderSearchNode sn, Planet p) {
		if (p.Owner() == 1 && sn.getFinalOwner(p) == 2)
			return true;
		return false;
	}

	public void ResetOptimal() {
		maxGrowth = 0;
	}

	public boolean TestState(OrderSearchNode osn) {
		int tg = osn.getGrowthRate();
		if (tg > maxGrowth)
		{
			maxGrowth = tg;
			return true;
		}
		return false;
	}

	public String getName() { return "DEFEND"; }
}