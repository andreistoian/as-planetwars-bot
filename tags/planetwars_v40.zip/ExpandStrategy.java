/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:25:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExpandStrategy extends OptimizingStrategy {
	int maxGrowth = 0;
	int maxShips = 0;
	public ExpandStrategy(PlanetWars pw) {
		super(pw);
	}
	public boolean FilterPlanet(OrderSearchNode sn, Planet p) {
		if (sn.getFinalOwner(p) == 1)
			return false;

		if (ClosestForce(pw, p) <= 0)
			return false;

		return true;
	}

	public boolean TestState(OrderSearchNode osn) {
		int gr = osn.getGrowthRate();
		int na = osn.getAvailShips();

		if (gr > maxGrowth)
		{
			maxGrowth = gr;
			maxShips = na;
			return true;
		}
		else if (gr == maxGrowth && na > maxShips)
		{
			maxShips = na;
			return true;
		}
		return false;
	}

	public String getName() { return "EXPAND"; }

	private int ClosestForce(PlanetWars pw, Planet p) {
		for (int i = 1; i < MyBot.maxDistance; ++i)
		{
			if (p.getShipsAtDistance()[i] != 0)
				return p.getShipsAtDistance()[i];
		}

		return 0;
	}
}
