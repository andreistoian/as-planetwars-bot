import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: andrei
 * Date: Oct 21, 2010
 * Time: 9:20:06 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class OptimizingStrategy extends Strategy {
	public OptimizingStrategy(PlanetWars pw) {
		super(pw);
	}

	private class PlanetConquestInfo
	{
		int nShips;
		int nAttackTime;

		public PlanetConquestInfo(int ns, int at) {
			nShips = ns;
			nAttackTime = at;
		}
	}

	protected abstract boolean FilterPlanet(OrderSearchNode sn, Planet p);
	protected abstract boolean TestState(OrderSearchNode osn);
	
	@Override
	public OrderSearchNode Run(OrderSearchNode startNode) {
		int nTried = 0;
		
		Queue<OrderSearchNode> searchQueue = new LinkedList<OrderSearchNode>();
		searchQueue.add(startNode);

		OrderSearchNode optimalOrders = startNode;
		
		long ticks = System.nanoTime();

		while (searchQueue.size() > 0)
		{
			OrderSearchNode currentNode = searchQueue.poll();
			nTried++;
//			Logger.AppendLog("POLLED NEW STATE, DONE " + nTried + " REMAIN: " + searchQueue.size(), false);

			boolean bAnyOrders = false;
			for (Planet p : pw.Planets())
			{
				PossibleOrder poLast = currentNode.orderList.size() > 0 ? currentNode.orderList.get(currentNode.orderList.size() - 1) : null;

				if (poLast != null && p.PlanetID() <= poLast.dst.PlanetID()) {
//					Logger.AppendLog("IGNORE " + p.PlanetID(), false);
					continue;
				}

				if (!FilterPlanet(currentNode, p)) {
//					Logger.AppendLog("IGNORE " + p.PlanetID(), false);
					continue;
				}

				PossibleOrder po = TryCapturePlanet(pw, p, currentNode);
				if (po != null)
				{
					Planet ps = po.parts.get(0).p;
//					Logger.AppendLog("PLANET CAPTURE " + po.toString(), false);

					OrderSearchNode nn = new OrderSearchNode(pw, currentNode, po);

					searchQueue.add(nn);
//					Logger.AppendLog("NEW SEARCH NODE: " + nn.prediction.get(pw.MyPlanets().get(0)).futureNumShips[0], false);
					bAnyOrders = true;
				}
			}

			if (!bAnyOrders) {
		   		if (TestState(currentNode)) {
//				   Logger.AppendLog("NEW GROWTH MAX " + currentNode.getGrowthRate() + "\nREMAIN " + currentNode.prediction.get(pw.MyPlanets().get(0)).futureSafeAvailable[0] , false);
/*					for (PossibleOrder po : currentNode.orderList) {
						Logger.AppendLog(po.toString(), false);
					}*/
					optimalOrders = currentNode;
				}
			}

//			Logger.AppendLog( "DONE NODE CREATION IN: " + ((System.nanoTime() - ticks) / 1000) + "us", false);
		}

//		Logger.AppendLog( "TRIED " + nTried + " NODES IN: " + ((System.nanoTime() - ticks) / 1000) + "us", false);

		return optimalOrders;
	}

	private PossibleOrder TryCapturePlanet(PlanetWars pw, Planet p, OrderSearchNode currentNode) {
		PlanetPrediction pp = currentNode.prediction.get(p);
		List<PlanetConquestInfo> ap = new ArrayList<PlanetConquestInfo>();
		for (int i = 1; i < MyBot.maxDistance; ++i)
			if (pp.futureInputNeeded[i] > 0)
				ap.add(new PlanetConquestInfo(pp.futureInputNeeded[i], i));

		Collections.sort(ap, new Comparator<PlanetConquestInfo>(){
			public int compare(PlanetConquestInfo o1, PlanetConquestInfo o2) {
				return o1.nShips - o2.nShips;
			}
		});

		for (PlanetConquestInfo pci : ap) {
			for (Planet ps : pw.MyPlanets()) {
				PlanetPrediction pps = currentNode.prediction.get(ps);
				int nNeeded = pci.nShips;
				PossibleOrder po = new PossibleOrder(p, p.GrowthRate());

				int avail = pps.futureSafeAvailable[0];

				if (p.getDistances()[ps.PlanetID()] == pci.nAttackTime && avail > 0)
				{
//					Logger.AppendLog("PLANET " + p.PlanetID() +  " NEEDS " + pci.nShips + " IN RANGE FOR ATTACK IN " + pci.nAttackTime, false);
					if (nNeeded < avail)
					{
						po.AddOrder(new PlanetOrder(ps, nNeeded, 0, currentNode.playerID));
						nNeeded = 0;
					}
					else
					{
						nNeeded -= avail;
						po.AddOrder(new PlanetOrder(ps, avail, 0, currentNode.playerID));
					}

//					Logger.AppendLog("PLANET " + p.PlanetID() +  " STILL NEEDS " + nNeeded, false);
					if (nNeeded > 0) {
						for (Planet aps : pw.MyPlanets()) {
							if (aps == ps)
								continue;
							int dap = aps.getDistances()[p.PlanetID()];
							if (dap > pci.nAttackTime)
								continue;

							PlanetPrediction paps = currentNode.prediction.get(aps);
							for (int k = 0; k < dap; ++k) {
								if (paps.futureAvailable[k] > 0) {
									nNeeded -= paps.futureAvailable[k];
									po.AddOrder(new PlanetOrder(aps, paps.futureAvailable[k], k, currentNode.playerID));
									break;
								}
							}
							if (nNeeded <= 0)
								break;
						}
					}
				}
				if (nNeeded <= 0)
				{
					return po;
				}
			}
		}
		return null;
	}
}
